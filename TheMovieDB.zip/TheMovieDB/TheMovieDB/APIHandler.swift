//
//  APIHandler.swift
//  TheMovieDB
//
//  Created by Mayank Mathur on 5/26/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

import UIKit
import Alamofire


let baseAPIUrl = "https://api.themoviedb.org/3/search/movie?api_key=9e398826a30bb0f823f05230ee99395b&language=en-US&query=%@&page=%d&include_adult=false"

class APIHandler: NSObject {
    
    static var sharedInstance = APIHandler()
    
    func getAllFiles(query: String, page: Int, completionHandler:@escaping (_ arr:[Movies], _ totalResults:Int)->()){
        
        let urlString = String(format: baseAPIUrl, arguments:[query,page])
        
        guard let pathUrl = URL(string: urlString) else {
            completionHandler([], 0)
            return
        }
        
        var urlRequest = URLRequest(url: pathUrl)
        urlRequest.httpMethod = "GET"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        Alamofire.request(urlRequest).validate().responseJSON { (response) in
            
            let dict = response.result.value as? Dictionary<String, Any>
            let page = dict?["page"] as? Int
            if let data = dict?["results"] as? Array<Dictionary<String,Any>>{
                let movieArray = data.map({ (movieDict) -> Movies in
                    Movies(JSON: movieDict)!
                })
                print(movieArray)
                
                completionHandler(movieArray, page!)
            }
        }
    }
}

