//
//  MovieDetailViewController.swift
//  TheMovieDB
//
//  Created by Mayank Mathur on 5/26/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

import UIKit
import SDWebImage

class MovieDetailViewController: BaseViewController {

    var movieDetail: Movies?
    
    @IBOutlet weak var moviePosterImage: UIImageView!
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var movieReleaseDate: UILabel!
    @IBOutlet weak var movieDescription: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "MOVIE DETAIL"

        setupInfo()
    }
    
    func setupInfo() {
        
        movieTitleLabel.text = movieDetail?.title!
        movieReleaseDate.text = movieDetail?.releaseDate!
        if let desc = movieDetail?.movieDescription!, desc != "" {
            movieDescription.text = desc
        }else{
            movieDescription.text = "Sorry, No Description available"
        }
        if let url =  getImageUrl(imagePath: movieDetail?.movieImage ?? "") as? URL {
            moviePosterImage.sd_setImage(with: url, placeholderImage: UIImage.init(named: "bigPlaceholder"))
            
        }
        moviePosterImage.layer.cornerRadius = 10
        moviePosterImage.clipsToBounds = true
        movieDescription.setContentOffset(CGPoint.zero, animated: true)

    }
    
    // make image path to download
    func getImageUrl(imagePath: String) -> URL {
        if let str1 = BaseImgURL as? String{
            
            let imageUrl = URL(string: str1+imagePath)
            return imageUrl!
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
