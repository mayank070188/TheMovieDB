//
//  MoviesViewController.swift
//  TheMovieDB
//
//  Created by Mayank Mathur on 5/26/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

import UIKit
import SVProgressHUD
import SDWebImage
import TWMessageBarManager

let BaseImgURL = "http://image.tmdb.org/t/p/w185"

class MoviesViewController: BaseViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    var moviePageCounter : Int = 1
    var moviesArray = [Movies]()
    // Any default value to start the search
    var queryString : String? = "A"
    
    @IBOutlet weak var sortingSegmentController: UISegmentedControl!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var moviesCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "MOVIE LIST"
    
        // Initial call to get data from API
        callMovieAPI(query: queryString!, pageNumber: moviePageCounter)
    }
    
    
    func callMovieAPI(query: String, pageNumber: Int)  {
        
        SVProgressHUD.show()
        APIHandler.sharedInstance.getAllFiles(query: query, page: pageNumber) { (arr, pageCount) in
            
            SVProgressHUD.dismiss()
            self.moviesArray.append(contentsOf: arr)
            // sort bt name
            self.moviesArray.sort(by: { $0.title! < $1.title! })
            self.moviePageCounter = pageCount
            self.moviesCollectionView.reloadData()
            
            // Only goes in for the first time we search query
            if(self.moviePageCounter == 1){
                DispatchQueue.main.async {
                    
                    if(self.moviesArray.count > 0){
                        TWMessageBarManager.sharedInstance().showMessage(withTitle: "Success", description: "Showing results for the \(query)", type: .info, duration: 2.0)
                        self.moviesCollectionView.setContentOffset(CGPoint .zero, animated: true)
                    }else{
                        TWMessageBarManager.sharedInstance().showMessage(withTitle: "Sorry", description: "No results for the \(query)", type: .error, duration: 2.0)
                    }
                }
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return moviesArray.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        
        let movie = moviesArray[indexPath.row] as Movies
        cell.movieTitleLabel.text = movie.title!
        
        if let url =  getImageUrl(imagePath: movie.movieImage ?? "") as? URL {
            cell.moviePosterImage.sd_setImage(with: url, placeholderImage: UIImage.init(named: "placeholder"))
            
        }
        
        // send request for more data for lazy loading
        if (indexPath.item == self.moviesArray.count - 4) {
            callMovieAPI(query: queryString!, pageNumber: moviePageCounter+1)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let movieDetailVC = UIStoryboard(name:"Main",bundle: nil).instantiateViewController(withIdentifier: "MovieDetailViewController") as! MovieDetailViewController
        let movie = moviesArray[indexPath.row]
        movieDetailVC.movieDetail = movie
        
        self.navigationController?.pushViewController(movieDetailVC, animated: true)
    }
    
    // maintaining cell size for different screens
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let padding: CGFloat = 70
        let collectionCellSize = collectionView.frame.size.width - padding
        
        return CGSize(width: collectionCellSize/2, height: 176.0)
    
    }
    
    // to make image path to download cover picture
    func getImageUrl(imagePath: String) -> URL {
        if let str1 = BaseImgURL as? String{
            
            let imageUrl = URL(string: str1+imagePath)
            return imageUrl!
        }
    }
    
    // segment controller action
    @IBAction func onTapSortOptions(_ sender: Any) {
        if sortingSegmentController.selectedSegmentIndex == 0 {
            moviesArray.sort(by: { $0.title! < $1.title! })
        } else if sortingSegmentController.selectedSegmentIndex == 0{
            moviesArray.sort(by: { $0.popularity! < $1.popularity! })
        }else{
            moviesArray.sort(by: { $0.releaseDate! < $1.releaseDate! })
        }
        
        moviesCollectionView.reloadData()
        moviesCollectionView.setContentOffset(CGPoint .zero, animated: true)
    }
    
    //MARK:-- SEARCH BAR DELEGATE
    
    // called when keyboard button pressed
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        moviePageCounter = 1
        moviesArray.removeAll()
        queryString = searchBar.text!
        
        callMovieAPI(query: queryString!, pageNumber: moviePageCounter)
        
        searchBar.resignFirstResponder()
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        searchBar.text = searchText.uppercased()
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        self.moviesCollectionView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
