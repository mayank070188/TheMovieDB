//
//  Movies.swift
//  TheMovieDB
//
//  Created by Mayank Mathur on 5/26/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

import UIKit
import ObjectMapper



class Movies: NSObject,Mappable {
    
    var movie_id : Int?
    var title : String?
    var movieImage : String?
    var movieDescription : String?
    var releaseDate : String?
    var popularity : Double?
    
    required init?(map: Map) {
   
    }
    
    func mapping(map: Map) {
        movie_id <- map["id"]
        title <- map["title"]
        movieImage <- map["poster_path"]
        movieDescription <- map["overview"]
        releaseDate <- map["release_date"]
        popularity <- map["popularity"]
    }
    
    
}
