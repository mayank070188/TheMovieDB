//
//  MovieCollectionViewCell.swift
//  TheMovieDB
//
//  Created by Mayank Mathur on 5/26/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var moviePosterImage: UIImageView!
    @IBOutlet weak var movieTitleLabel: UILabel!
    
    // to round the corners of the Collectionview cell
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.masksToBounds = true
        self.layer.cornerRadius = 10
    }
    
}
